    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.js"></script>
    <script src="js/bootstrap-datepicker.js"></script>
    <script src="js/bootstrap-datepicker.ro.min.js"></script>
    <script src="js/ie10-viewport-bug-workaround.js"></script>
    <script>
    $('#sandbox-container input').datepicker({
    });
    </script>
    <!-- script> 
    $('#addclient').click(function(){
      window.open("php/addclient.php");
    });
  </script--->
  </body>
</html>
