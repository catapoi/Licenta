<?php
include "functii.php";
if (!empty($_POST['email']) && !empty($_POST['nume']) && !empty($_POST['nr_reg_com']) && !empty($_POST['cif']) && !empty($_POST['adrsediu'])
  && !empty($_POST['judet']) && !empty($_POST['iban']) && !empty($_POST['banca']) ) {
    $email = $_POST['email'];
    $nume = $_POST['nume'];
    $nr_reg_com = $_POST['nr_reg_com'];
    $cif = $_POST['cif'];
    $adrsediu=$_POST['adrsediu'];
    $judet=$_POST['judet'];
    $iban=$_POST['iban'];
    $banca=$_POST['banca'];
  } else {
    include "../header.php";
    echo "Ati introdus date eronate sau lipsa";
  }




 ?>
