<?php
if (!empty($_POST['username']) && !empty($_POST['password']) && !empty($_POST['role']) && !empty($_POST['email'])) {
  $username=$_POST['username'];
  $password=$_POST['password'];
  $role=$_POST['role'];
  $email=$_POST['email'];
}

$mysqli = new mysqli("localhost", "root", "", "licenta");
/* check connection */
if ($mysqli->connect_errno) {
    printf("Nu se poate realiza conexiunea : %s\n", $mysqli->connect_error);
    exit();
} else {
  $sql = "INSERT INTO users (name, password, role, email) VALUES ('$username', '$password', '$role', '$email')";
  if (mysqli_query($mysqli, $sql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
}

/* Select queries return a resultset */
/*
if ($result = $mysqli->query("SELECT * FROM users ", MYSQLI_USE_RESULT)) {
    printf("Select returned %d rows.\n", $result->num_rows);

    /* free result set */
/*
    $result->close();
}
*/

$mysqli->close();
header('Location: ../admin.php');


?>
