<?php
$mysqli = new mysqli("localhost", "root", "", "licenta");
/* check connection */
if ($mysqli->connect_errno) {
    printf("Nu se poate realiza conexiunea : %s\n", $mysqli->connect_error);
    exit();
}

 ?>
