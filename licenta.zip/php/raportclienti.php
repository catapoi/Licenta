<?php
require('libs/fpdf181/fpdf.php');
//Connect to your database
include('functii.php');

$timezone = date_default_timezone_get();
$date = date('d-m-Y H:i:s');

//Create new pdf file
$pdf=new FPDF();

//Disable automatic page break
$pdf->SetAutoPageBreak(false);

//Add first page
$pdf->AddPage('L');

//logo

$pdf->Image('../pics/logo.png',10,6,30);
// Arial bold 15
$pdf->SetFont('Times', 'B', 12);
// Move to the right
$pdf->Cell(60);
// Title
$pdf->Cell(80,10,'Raport Clienti RedEyeSystem  ' .$date,12,0,'C');
// Line break
$pdf->Ln(20);

//set initial y axis position per page
$y_axis_initial = 40;

$y_axis = 40;
//Set Row Height
$row_height = 6;

//print column titles
$pdf->SetFillColor(232, 232, 232);
$pdf->SetFont('Times', 'B', 8);
$pdf->SetY($y_axis_initial);
$pdf->SetX(25);
$pdf->Cell(12, 6, 'Nr. Crt', 1, 0, 'L', 1);
$pdf->Cell(35, 6, 'Email', 1, 0, 'L', 1);
$pdf->Cell(25, 6, 'Nume', 1, 0, 'L', 1);
$pdf->Cell(25, 6, 'Reg Comertului', 1, 0, 'R', 1);
$pdf->Cell(25, 6, 'Cod fiscal', 1, 0, 'R', 1);
$pdf->Cell(40, 6, 'Adresa', 1, 0, 'R', 1);
$pdf->Cell(20, 6, 'Judet', 1, 0, 'R', 1);
$pdf->Cell(40, 6, 'IBAN', 1, 0, 'R', 1);
$pdf->Cell(20, 6, 'Banca', 1, 0, 'R', 1);
$y_axis = $y_axis + $row_height;

//Select the users you want to show in your PDF file
$sql = "SELECT email, nume , nr_reg_com, cif, adrsediu, judet, iban, banca FROM clienti";
$result=$mysqli->query($sql);

//initialize counter
$i = 0;

//Set maximum rows per page
$max = 25;

//Set Row Height
$row_height = 6;
$j=1;
while($row = mysqli_fetch_array($result))
{
    //If the current row is the last one, create new page and print column title
    if ($i == $max)
    {
        $pdf->AddPage();

        //print column titles for the current page
        $pdf->SetY($y_axis_initial);
        $pdf->SetX(25);
        $pdf->Cell(12, 6, 'Nr. Crt', 1, 0, 'L', 1);
        $pdf->Cell(35, 6, 'Email', 1, 0, 'L', 1);
        $pdf->Cell(25, 6, 'Nume', 1, 0, 'L', 1);
        $pdf->Cell(25, 6, 'Regitrul comertului', 1, 0, 'R', 1);
        $pdf->Cell(25, 6, 'Cod fiscal', 1, 0, 'R', 1);
        $pdf->Cell(40, 6, 'Adresa', 1, 0, 'R', 1);
        $pdf->Cell(20, 6, 'Judet', 1, 0, 'R', 1);
        $pdf->Cell(40, 6, 'IBAN', 1, 0, 'R', 1);
        $pdf->Cell(20, 6, 'Banca', 1, 0, 'R', 1);
        //Go to next row
        $y_axis = $y_axis + $row_height;

        //Set $i variable to 0 (first row)
        $i = 0;
    }
    $nrcrt = $j;
    $email = $row['email'];
    $nume = $row['nume'];
    $nrregcom = $row['nr_reg_com'];
    $codfiscal = $row['cif'];
    $adresa = $row['adrsediu'];
    $judet = $row['judet'];
    $iban = $row['iban'];
    $banca = $row['banca'];
    $pdf->SetY($y_axis);
    $pdf->SetX(25);
    $pdf->Cell(12, 6, $j, 1, 0, 'L', 1);
    $pdf->Cell(35, 6, $email, 1, 0, 'L', 1);
    $pdf->Cell(25, 6, $nume, 1, 0, 'L', 1);
    $pdf->Cell(25, 6, $nrregcom, 1, 0, 'R', 1);
    $pdf->Cell(25, 6, $codfiscal, 1, 0, 'R', 1);
    $pdf->Cell(40, 6, $adresa, 1, 0, 'R', 1);
    $pdf->Cell(20, 6, $judet, 1, 0, 'R', 1);
    $pdf->Cell(40, 6, $iban, 1, 0, 'R', 1);
    $pdf->Cell(20, 6, $banca, 1, 0, 'R', 1);
    //Go to next row
    $y_axis = $y_axis + $row_height;
    $i = $i + 1;
    $j = $j + 1;
}

mysqli_close($mysqli);

//Send file
$pdf->Output();
?>
