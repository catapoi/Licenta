<?php
include 'functii.php';

$result = mysqli_query($mysqli,"SELECT id, sold FROM casa ORDER BY id DESC LIMIT 1");
while($row = mysqli_fetch_array($result))
{
echo "<td>" . $row['sold'] . "</td>";
}
mysqli_close($mysqli);
?>
