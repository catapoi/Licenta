<?php
require('libs/fpdf181/fpdf.php');
include 'functii.php';
class PDF extends FPDF
{
// Page header
function Header()
{
    // Logo
    $this->Image('../pics/logo.png',10,6,30);
    // Arial bold 15
    $this->SetFont('Arial','B',15);
    // Move to the right
    $this->Cell(80);
    // Title
    $this->Cell(30,10,'Raport utilizatori',15,0,'C');
    // Line break
    $this->Ln(20);
}

// Page footer
function Footer()
{
    // Position at 1.5 cm from bottom
    $this->SetY(-15);
    // Arial italic 8
    $this->SetFont('Arial','I',8);
    // Page number
    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}
}

// Instanciation of inherited class
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Times','',12);


$sql = "SELECT * FROM users";
$result = mysqli_query($mysqli,$sql)or die(mysqli_error());
$i=10;
while($row = mysqli_fetch_array($result)) {
  $name = $row['name'];
  $role = $row['role'];
  $email = $row['email'];
  $pdf->Cell(0,$i, $name .$i . " " . $name . " " . $role . $i,0,1);
  #echo "<tr><td>".$name ."</td><td>".$role."</td><td>".$email."</td></tr>";
}
mysqli_close($mysqli);


/* for($i=1;$i<=40;$i++)
    $pdf->Cell(0,10,'Printing line number '.$i,0,1);
    */
  $pdf->Output();

 ?>
