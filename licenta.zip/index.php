<?php
include "header.php";
?>

    <div class="container">


      <div class="jumbotron">
        <h3>Bine ati venit la Red Eye Systems</h3>
        <!--p>This example is a quick exercise to illustrate how the default, static and fixed to top navbar work.
        It includes the responsive CSS and HTML, so it also adapts to your viewport and device.</p>
        <p>To see the difference between static and fixed top navbars, just scroll.</p>
        <p -->
        <p>  <img src="pics/logo.png" class="img-rounded" alt="Cinque Terre" width=100% height="auto"> </p>
          <a class="btn btn-lg btn-primary" href="../../components/#navbar" role="button">Continuati &raquo;</a>
        </p>
      </div>



    
    </div> <!-- /container -->
<?php
include "footer.php";
 ?>
