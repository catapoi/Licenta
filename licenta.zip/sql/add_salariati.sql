INSERT INTO `salariati` (`id_sal`, `nume`, `prenume`, `CNP`, `datan`, `functia`, `salariu`, `domiciliul`) VALUES
(NULL, 'Poienaru', 'George', '1851022170043', '1985-10-22', 'Inginer sistem', '6000', 'Bucuresti, Lalosului 2 sector 4'),
(NULL, 'Poienaru', 'Catalin', '1790115044421', '1979-01-15', 'Inginer sistem', '6000', 'Bucuresti, 1 Mai nr 22 sector 6'),
(NULL, 'Diac', 'Mihai', '1850122170043', '1985-01-22', 'Inginer sistem', '6000', 'Bucuresti, Preciziei 26 sector 6');
