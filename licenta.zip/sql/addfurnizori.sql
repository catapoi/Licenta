INSERT INTO `furnizori` (`id`, `email`, `nume`, `nr_reg_com`, `cif`, `adrsediu`, `judet`, `iban`, `banca`) VALUES
(NULL, 'contact@romtelecom.ro', 'SC ROMTELECOM SA', 'J40/1848/1998', '11726360', 'CALEA VICTORIEI 35 C Bucuresti', 'BUCURESTI', 'RO49RNCB0070005630320001', 'BCR'),
(NULL, 'contact@RCSRDS.ro', 'RCS RDS', 'J04/1511/1999', '6268111', 'Str. Doctor Staicovici, Nr 75', 'BUCURESTI', 'RO49RNCB0070005630120001', 'BCR'),
(NULL, 'contact@MAGICPRINT.ro', 'MAGIC Print SRL', 'J04/151/1991', '3534111', 'Pacii  1 Onesti', 'BACAU', 'RO49RNCB0070005630122222', 'BCR'),
(NULL, 'contact@DELL.ro', 'DELL ROMANIA SA', 'J01/101/1994', '3332111', 'Bulevardul Dimitrie Pompeiu 10A', 'BUCURESTI', 'RO49RNCB0070005630120333', 'BCR'),
(NULL, 'office@copyshop.ro', 'Copy SHOP SRL ', 'J02/11/1994', '3031111', 'George Calinescu 11 Onesti', 'BACAU', 'RO49RNCB0070005630126666', 'BCR');
