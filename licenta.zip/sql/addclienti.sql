INSERT INTO `clienti` (`id`, `email`, `nume`, `nr_reg_com`, `cif`, `adrsediu`, `judet`, `iban`, `banca`) VALUES
(NULL, 'contact@croco.ro', 'SC CROCO SA', 'J04/1541/1994', '6268054', 'Calea Slanicului 12, Onești', 'BACAU', 'RO49RNCB0080005630320001', 'BCR');

INSERT INTO `clienti` (`id`, `email`, `nume`, `nr_reg_com`, `cif`, `adrsediu`, `judet`, `iban`, `banca`) VALUES
(NULL, 'contact@primarieonesti.ro', 'Primaria Onesti', 'J04/1511/1990', '6268111', 'Bulevardul Oituz 17 Onesti', 'BACAU', 'RO49RNCB0080005630120001', 'BCR'),
(NULL, 'contact@apacanal.ro', 'APA Canal SA', 'J04/151/1996', '3534111', 'Pacii  17 Onesti', 'BACAU', 'RO49RNCB0080005630122222', 'BCR'),
(NULL, 'contact@servsal.ro', 'SERVSAL SA', 'J01/101/1998', '3332111', 'Sintezei 13 Onesti', 'BACAU', 'RO49RNCB0080005630120333', 'BCR'),
(NULL, 'office@grup-serban.ro', 'Grup Serban SA', 'J02/119/1994', '3030111', 'George Clinescu 1 Onesti', 'BACAU', 'RO49RNCB0080005630126666', 'BCR');
